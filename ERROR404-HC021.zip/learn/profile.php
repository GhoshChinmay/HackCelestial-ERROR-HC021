<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hack";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch specific columns from the 'profile' table
$sql = "SELECT * from info ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $user_name = $row["name"];
    $user_dob = $row["dob"];
    $user_city = $row["city"];
    $user_language = $row["language"];
    $user_profession = $row["profession"];
    $user_skill = $row["skill"]; // Assuming you have a 'skill' column
    $user_weaksubject = $row["weaksubject"];
    $user_strongsubject = $row["strongsubject"];
} else {
    // Handle the case where no user is found
    $user_name = "";
    $user_dob = "";
    $user_city = "";
    $user_language = "";
    $user_profession = "";
    $user_skill = "";
    $user_weaksubject = "";
    $user_strongsubject = "";
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile</title>
    <link rel="stylesheet" href="profile.css">
</head>
<body>
    <div class="container">
        <div class="profile-header">
            <img src="profile-icon.png" alt="Profile Icon" class="profile-icon">
            <h1>Student Profile</h1>
        </div>

        <div id="profile-details">
            <h2>Personal Details</h2>
            <div class="detail-group">
                <p><strong>Name:</strong> <span id="profile-name"></span></p>
                <p><strong>Date Of Birth:</strong> <span id="profile-dob"></span></p>
                <p><strong>City:</strong> <span id="profile-city"></span></p>
                <p><strong>Language:</strong> <span id="profile-lang"></span></p>
            </div>

            <h2>Education Details</h2>
            <div class="detail-group">
                <p><strong>Profession:</strong> <span id="profile-college"></span></p>
                <p><strong>Skills:</strong> <span id="profile-degree"></span></p>
                <p><strong>Strong Subject:</strong> <span id="profile-str"></span></p>
                <p><strong>Weak Subject:</strong> <span id="profile-weak"></span></p>
            </div>
        </div>

        <button id="edit-profile" class="btn-edit">Edit Profile</button>
    </div>

    <script>
        // Load profile data from localStorage
        const fullName = localStorage.getItem('fullName');
        const email = localStorage.getItem('email');
        const phone = localStorage.getItem('phone');
        const college = localStorage.getItem('college');
        const degree = localStorage.getItem('degree');

        // Display the data on the profile page
        document.getElementById('profile-name').textContent = fullName || "N/A";
        document.getElementById('profile-email').textContent = email || "N/A";
        document.getElementById('profile-phone').textContent = phone || "N/A";
        document.getElementById('profile-college').textContent = college || "N/A";
        document.getElementById('profile-degree').textContent = degree || "N/A";

        // Edit Profile
        document.getElementById('edit-profile').addEventListener('click', function() {
            const newName = prompt('Enter new name:', fullName);
            const newEmail = prompt('Enter new email:', email);
            const newPhone = prompt('Enter new phone number:', phone);
            const newCollege = prompt('Enter new college:', college);
            const newDegree = prompt('Enter new degree:', degree);

            // Update localStorage with new values
            localStorage.setItem('fullName', newName);
            localStorage.setItem('email', newEmail);
            localStorage.setItem('phone', newPhone);
            localStorage.setItem('college', newCollege);
            localStorage.setItem('degree', newDegree);

            // Refresh the page to display updated values
            window.location.reload();
        });
    </script>
</body>
</html>